


import pandas as pd

online_retail = pd.read_csv(r'Online Retail_Sample.csv', encoding = 'ISO-8859-1')
online_retail

online_retail.shape
sample_data = online_retail.sample(n=1000)
sample_data
sample_data.shape

sample_data1 = online_retail.sample(n=1000)
sample_data1
sample_data1.shape

up_mean = online_retail['UnitPrice'].mean()
up_mean

up_median = online_retail['UnitPrice'].median()
up_median

quantity_mean = online_retail['Quantity'].mean()
quantity_mean

quantity_median = online_retail['Quantity'].median()
quantity_median


income = pd.read_csv(r'Income_data.csv')
income

gain_mean = income["capital-gain"].mean()
gain_mean


gain_median = income['capital-gain'].median()
gain_median

usa_income = income[income['native-country'] == ' United-States']
usa_income

other_income = income[income['native-country'] != ' United-States']
other_income

## var and sd of uSA
var_usa = usa_income['education-num'].var()
var_usa

std_usa = usa_income['education-num'].std()
std_usa


var_other = other_income['education-num'].var()
var_other

std_other = other_income['education-num'].std()
std_other

income['capital-gain'].describe()

income['capital-gain'].quantile([0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1])
income['capital-loss'].quantile([0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1])

income['hours-per-week'].quantile([0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1])


cars = pd.read_csv(r'D:\learnings\training\programs\Cars Data\Cars.csv')
cars

cars['Horsepower'].describe()

# to draw graphs
# graphas gives an idea how the data is distributed
import matplotlib.pyplot as plt
plt.scatter(cars['Horsepower'], cars['MPG_City'])

cars.shape

cars['Cylinders'].value_counts()
freq = cars['Cylinders'].value_counts()
freq.values
freq.index

plt.bar(freq.index ,freq.values)
plt.savefig('output.jpg')


import os
os.getcwd()

















