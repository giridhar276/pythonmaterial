import pandas as pd

gdp = pd.read_csv(r"GDP.csv"  , encoding = 'ISO-8859-1')

gdp

gdp.shape

gdp.columns.values

gdp1 = gdp.head(10)
gdp1

gdp2 = gdp.iloc[[2,6,56,69]]    # display the selected records
gdp2


gdp3 = gdp['Country']
gdp3

gdp3 = gdp[['Country','Rank']]
gdp3

gdp4 = gdp[['Country','Rank']][0:10]
gdp4

# delete columns 
gdp5 = gdp.drop(['Country_code','GDP'] ,axis=1)
gdp5.head(2)



# delete rows
gdp6 = gdp.drop(gdp.index[0] , axis = 0)
gdp6


gdp7 = gdp.drop(gdp.index[[3,4,5,89]] , axis = 0)
gdp7


# remove records in bulk
rows_to_exclude = list(range(3,101))
gdp8 = gdp.drop(gdp.index[rows_to_exclude] , axis = 0)
gdp8


col_to_keep = ['Country','GDP']
col_to_drop = ["Country","Country_code"]
rows_to_keep = list(range(50,81))
rows_to_drop = ["Country","Country_code"]

# keeping selected rows and keeping selected cols
gdp9 = gdp[col_to_keep].iloc[rows_to_keep]
gdp9.head()


#keeping selected rwos and dropping selected cols
gdp10 = gdp.drop(col_to_drop, axis = 1).iloc[rows_to_keep]
gdp10.head()


## How to extract colname by giving index
col_names_array = gdp.columns.values
index_base = col_names_array[1]
print(index_base)


### filters and conditions 


bank_data = pd.read_csv(r'bank_market.csv')
bank_data.shape

# condition
# select * from bank_detail where age > 40
bank_data['age'] > 40
bank_subset1 = bank_data[bank_data['age'] > 40]
bank_subset1
bank_subset2 = bank_data[bank_data['loan'] == 'no']
bank_subset2

bank_subset = bank_data[(bank_data['age'] > 40)  & (bank_data['loan'] == 'no')]
bank_subset


# using both filters ( and , or)
bank_subset3 = bank_data[(bank_data['age'] > 40) & (bank_data['loan'] == 'no') | (bank_data['marital'] == 'single') ]
bank_subset3

#df[() & ()]


bank_data = pd.read_csv(r'D:\learnings\training\programs\Bank Tele Marketing\bank_market.csv')
bank_data.shape



online_retail = pd.read_csv(r'D:\learnings\training\programs\Online Retail Sales Data\Online Retail_Sample.csv',encoding = 'ISO-8859-1')
online_retail

online_retail.shape
online_retail.head(2)
online_retail.columns.values

# sort
online_retail_sort = online_retail.sort_values(by = 'UnitPrice')
online_retail_sort
online_retail_sort.head(2)
online_retail_sort.tail(20)

online_retail_sort_desc = online_retail.sort_values(by = 'UnitPrice', ascending= False)
online_retail_sort_desc

online_retail_sort2 = online_retail.sort_values(by = ['UnitPrice','Country'])
online_retail_sort2


bill_data = pd.read_csv(r'D:\learnings\training\programs\Telecom Data Analysis\Bill.csv')
bill_data    # 9462
######
dupes = bill_data.duplicated()
dupes
sum(dupes)
# looking for completed duplicated record
bill_data_uniq = bill_data.drop_duplicates()
bill_data_uniq
bill_data_uniq.shape   # 9452

## applying drop_duplicates on single column
bill_data_cust_uniq = bill_data.drop_duplicates(['cust_id'])
bill_data_cust_uniq


# merging dataframes

orders = pd.read_csv(r'orders.csv')
orders
orders.shape

slots = pd.read_csv(r'slots.csv')
slots
slots.shape

#duplicates based on cust_id
sum(orders.Unique_id.duplicated())
sum(slots.Unique_id.duplicated())

orders1 = orders.drop_duplicates(['Unique_id'])
slots1 = slots.drop_duplicates(['Unique_id'])

## pd.merge( df1 , df2 , on = <key column> ,  how = <join type>)

## inner join
inner_data = pd.merge(orders1,slots1 , on = 'Unique_id' ,how = 'inner')
inner_data


## outer join
outer_data =  pd.merge(orders1,slots1 , on = 'Unique_id' ,how = 'outer')
outer_data

# lett outer join
left_outer_data  = pd.merge(orders1, slots1 , on = 'Unique_id' , how = 'left')
left_outer_data



















