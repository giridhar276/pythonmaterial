
import pandas as pd

sales = pd.read_csv(r"D:\learnings\training\programs\Superstore Sales Data\Sales_sample.csv")

sales['custName']

sales.shape

sales.columns.values  # display all column names

sales.head(2)  # top 2 records

sales.tail()  # display last 5 records by default

sales.tail(2) # display last 2 records

sales.dtypes

sales.describe()

sales['unitsSold'].describe()

sales.unitsSold.describe()

sales['salesChannel'].value_counts()

sales.custId.isnull()   # to check presense of missing values  NaN

sum(sales.custId.isnull())

sales.sample(n=4)








