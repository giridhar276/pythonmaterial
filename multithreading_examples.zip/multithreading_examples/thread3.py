import threading

def first_function():
    for i in range(5):

        print ('Executing the first funcion')

def second_function():
    for i in range(5):
        print ('Executing the second funcion')

if __name__=="__main__":
    thread_one = threading.Thread(target=first_function)
    thread_two = threading.Thread(target=second_function)

    thread_one.start()
    thread_two.start()

    thread_one.join()
    thread_two.join()