#!/usr/bin/python


## This program adds two given numbers and prints the result.


import threading 

def MyFunction(num1, num2):
    """This is user defined thread function"""
    print("Given numbers= {}, {}".format(num1, num2))
    getsum = int(num1) + int(num2)
    print("Result = {} ".format(str(getsum)))
    return
    

def main():
	 t = threading.Thread( target=MyFunction,args=(12,13))
	 t.start()


if __name__ == '__main__':
	 main()
