class Student:
    'Common base class for all student'
    studentCount = 0
    def __init__(self,name,fee,age):
        self.name = name
        self.fee = fee
        self.age = age
        Student.studentCount += 1

    def displayCount(self):
        print("Total Students %d" % Student.studentCount )

    def displayStudent(self):
        print("Name : ", self.name , ", Fee : ", self.fee)

    def displayAge(self):
        print("Name : ", self.name , ",Age: ", self.age )


student1 = Student("Ebby",2500,17)
student1.displayStudent()
student1.displayAge()

print("\n Example Program -2 : Accessing attributes\n")
print("hasattb: ", hasattr(student1,'age')) # returns true if 'age' attribute exists
print("getattb: ", getattr(student1,'age')) # returns value of you can add, rem
print("setattb: ", setattr(student1,'age',19)) # set attribute 'age' to 19
print("getattr after setattr with new value: ", getattr(student1, 'age'))


print("Total students %d " % Student.studentCount)
