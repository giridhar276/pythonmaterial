# Instance methods are also known as Bound methods since the methods
# within a class are bound to the instance created from the class, via
# 'self'.


class A(object):
    def method(*argv):
        return argv

a = A()
print(a.method())